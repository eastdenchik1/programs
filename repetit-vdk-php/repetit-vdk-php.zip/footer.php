
<footer>
    <DIV class="container"><br><br>     
    <span class="align-middle">REPETIT-VDK.  -  by <a href="https://eastdenchik1.github.io/">Eastdenchik</a> &copy; <?=date("Y");?>
    </DIV>
</footer>